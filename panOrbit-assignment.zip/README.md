# PanOrbit Assignment
PanOrbit Assignment built with Angular

## Requirements
- Install [NodeJS]

## Setup
2. Change to panOrbit-assignment directory.

3. Install dependencies from npm (Node.js required).

npm install

4. Run Server

ng serve

5. Open localhost on port 4200:

http://localhost:4200/
